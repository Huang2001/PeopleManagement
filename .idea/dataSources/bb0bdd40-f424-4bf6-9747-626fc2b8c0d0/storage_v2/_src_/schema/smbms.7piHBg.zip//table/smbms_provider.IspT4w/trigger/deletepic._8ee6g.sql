create definer = root@`%` trigger deletepic
    after delete
    on smbms_provider
    for each row
    delete from pro_pic
    where pro_code=old.proCode;

