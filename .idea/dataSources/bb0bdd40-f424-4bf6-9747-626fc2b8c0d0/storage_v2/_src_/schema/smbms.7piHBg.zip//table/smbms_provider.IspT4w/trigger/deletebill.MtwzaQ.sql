create definer = root@`%` trigger deletebill
    after delete
    on smbms_provider
    for each row
    delete from smbms_bill where smbms_bill.providerId=old.id;

